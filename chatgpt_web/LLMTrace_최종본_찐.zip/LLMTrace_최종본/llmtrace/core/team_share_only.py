from __future__ import annotations

import os
import platform
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, Optional

from .acquisition import prepare_input
from .engine import run_all
from .mapping import process_surface
from .parsers import run_profile_parsers
from .profile import load_profile
from .schema import Ids, Problem
from .team_share import (
    DEFAULT_CSV_FILENAME,
    DEFAULT_HTML_FILENAME,
    PARSED_ARTIFACTS_FILENAME,
    export_team_share,
)


COLLECTED_ARTIFACTS_FILENAME = 'collected_artifacts.zip'


def _emit(progress: Optional[Callable[[Dict[str, object]], None]],
          event: str, **values: object) -> None:
    if progress is not None:
        progress({'event': event, **values})


def _validate_final_directory(output: Path, csv_name: str,
                              html_name: str, parsed_name: str,
                              preserved_entries: Iterable[str] = ()) -> None:
    if not output.exists():
        return
    if not output.is_dir():
        raise ValueError(f'저장 경로가 폴더가 아닙니다: {output}')
    allowed = {csv_name, html_name, parsed_name, *preserved_entries}
    unexpected = sorted(item.name for item in output.iterdir()
                        if item.name not in allowed)
    if unexpected:
        preview = ', '.join(unexpected[:5])
        if len(unexpected) > 5:
            preview += f' 외 {len(unexpected) - 5}개'
        raise ValueError(
            '최종 결과 폴더에 다른 파일이 있습니다. '
            '빈 폴더나 이 도구가 만든 결과 폴더를 지정하세요: '
            f'{preview}'
        )


def _publish_team_share(staged: Dict[str, Any], output: Path,
                        progress: Optional[Callable[[Dict[str, object]], None]],
                        preserved_entries: Iterable[str] = ()) \
        -> Dict[str, Any]:
    source_csv = Path(str(staged['csv']))
    source_html = Path(str(staged['html']))
    source_json = Path(str((staged.get('raw_data') or {}).get('file') or ''))
    _validate_final_directory(
        output, source_csv.name, source_html.name, source_json.name,
        preserved_entries,
    )
    output.mkdir(parents=True, exist_ok=True)

    final_csv = output / source_csv.name
    final_html = output / source_html.name
    final_json = output / source_json.name
    temp_csv = output / f'.{source_csv.name}.tmp'
    temp_html = output / f'.{source_html.name}.tmp'
    temp_json = output / f'.{source_json.name}.tmp'

    try:
        _emit(progress, 'report_started', report_type='CSV', path=str(final_csv))
        shutil.copyfile(source_csv, temp_csv)
        os.replace(temp_csv, final_csv)
        _emit(progress, 'report_completed', report_type='CSV', path=str(final_csv))

        _emit(progress, 'report_started', report_type='HTML', path=str(final_html))
        shutil.copyfile(source_html, temp_html)
        os.replace(temp_html, final_html)
        _emit(progress, 'report_completed', report_type='HTML', path=str(final_html))

        _emit(progress, 'report_started', report_type='JSON', path=str(final_json))
        shutil.copyfile(source_json, temp_json)
        os.replace(temp_json, final_json)
        _emit(progress, 'report_completed', report_type='JSON', path=str(final_json))
    finally:
        for temporary in (temp_csv, temp_html, temp_json):
            if temporary.exists():
                temporary.unlink()

    result = dict(staged)
    result.update({
        'csv': str(final_csv),
        'html': str(final_html),
        'parsed_artifacts': str(final_json),
        'output': str(output),
        'self_contained_html': True,
    })
    result.pop('raw_data', None)
    return result


def _archive_collected_artifacts(
        source: Path, archive: Path,
        progress: Optional[Callable[[Dict[str, object]], None]]) -> Dict[str, Any]:
    """Save the parser input tree as one atomic ZIP archive."""
    source = source.resolve()
    archive = archive.resolve()
    if not source.is_dir():
        raise ValueError(f'수집 아티팩트 폴더가 없습니다: {source}')

    archive.parent.mkdir(parents=True, exist_ok=True)
    temporary = archive.with_name(f'.{archive.name}.tmp')
    file_count = 0
    source_bytes = 0
    _emit(
        progress,
        'collection_archive_started',
        source=str(source),
        path=str(archive),
    )
    try:
        with zipfile.ZipFile(
            temporary,
            mode='w',
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=6,
            allowZip64=True,
            strict_timestamps=False,
        ) as bundle:
            for item in sorted(source.rglob('*'), key=lambda value: str(value).lower()):
                if not item.is_file():
                    continue
                relative = item.relative_to(source).as_posix()
                bundle.write(item, relative)
                file_count += 1
                source_bytes += item.stat().st_size
        os.replace(temporary, archive)
    finally:
        if temporary.exists():
            temporary.unlink()

    result = {
        'path': str(archive),
        'files': file_count,
        'source_bytes': source_bytes,
        'archive_bytes': archive.stat().st_size,
    }
    _emit(progress, 'collection_archive_completed', **result)
    return result


def run_team_share_only(profile_name: str, output_dir: str, *, input_root: str,
                        partition: Optional[int] = None,
                        include_noise: bool = False,
                        progress: Optional[Callable[[Dict[str, object]], None]] = None,
                        source_context: Optional[Dict[str, str]] = None,
                        preserved_entries: Iterable[str] = (),
                        collected_artifacts_archive: Optional[str] = None) \
        -> Dict[str, Any]:
    """Analyze a source while publishing only the team-share result files."""
    profile = load_profile(profile_name)
    ids = Ids()
    problems: list[Problem] = []
    output = Path(output_dir).resolve()
    config = profile.team_share
    archive_path = (
        Path(collected_artifacts_archive).resolve()
        if collected_artifacts_archive else None
    )
    if archive_path is not None and archive_path.parent != output:
        raise ValueError(
            '수집 아티팩트 ZIP은 최종 결과 폴더 안에 저장해야 합니다: '
            f'{archive_path}'
        )
    allowed_entries = tuple(dict.fromkeys((
        *preserved_entries,
        *((archive_path.name,) if archive_path is not None else ()),
    )))
    _validate_final_directory(
        output,
        getattr(config, 'CSV_FILENAME', DEFAULT_CSV_FILENAME),
        getattr(config, 'HTML_FILENAME', DEFAULT_HTML_FILENAME),
        PARSED_ARTIFACTS_FILENAME,
        allowed_entries,
    )
    work_parent = output.parent if output.parent.is_dir() else None

    with tempfile.TemporaryDirectory(
        prefix='.llmtrace-team-share-',
        dir=str(work_parent) if work_parent is not None else None,
    ) as temporary_root:
        work = Path(temporary_root)
        _emit(progress, 'source_preparation_started', input=input_root)
        prepared_input, acquisition = prepare_input(
            input_root,
            profile,
            str(work),
            partition=partition,
            include_noise=include_noise,
        )
        _emit(
            progress,
            'source_preparation_completed',
            input=input_root,
            prepared_input=prepared_input,
            acquisition=acquisition.as_dict() if acquisition is not None else None,
        )

        raw_records = run_profile_parsers(
            prepared_input,
            profile,
            problems=problems,
            ids=ids,
            progress=progress,
        )
        _emit(
            progress,
            'artifact_collection_completed',
            raw_record_count=len(raw_records),
            source_count=len({row.source_path for row in raw_records if row.source_path}),
            problem_count=len(problems),
            acquisition=acquisition.as_dict() if acquisition is not None else None,
        )

        try:
            observations = process_surface(raw_records, profile, ids)
        except Exception as exc:
            problems.append(Problem(
                id=ids.next('problem'),
                stage='mapping',
                severity='error',
                code='surface_mapping_failed',
                message=f'{type(exc).__name__}: {exc}',
                profile=profile.name,
                source_path=str(prepared_input),
            ))
            observations = []

        _emit(progress, 'action_analysis_started')
        try:
            inferences, _contexts = run_all(observations, profile.rules, ids)
        except Exception as exc:
            problems.append(Problem(
                id=ids.next('problem'),
                stage='rules',
                severity='error',
                code='rule_engine_failed',
                message=f'{type(exc).__name__}: {exc}',
                profile=profile.name,
            ))
            inferences = []
        _emit(
            progress,
            'action_analysis_completed',
            inferences=inferences,
            contexts=[],
        )

        context = dict(source_context or {})
        source_value = context.get('source') or input_root
        if not context.get('source_type'):
            suffix = Path(source_value).suffix.lstrip('.').upper()
            context['source_type'] = suffix or 'COLLECTED FOLDER'
        context.setdefault('source', source_value)
        context.setdefault('machine', platform.node())
        context.setdefault(
            'os',
            ' '.join(part for part in (platform.system(), platform.release()) if part),
        )

        staged = export_team_share(
            profile,
            str(work / 'team_share'),
            observations=observations,
            inferences=inferences,
            environment=context,
        )
        published = _publish_team_share(
            staged, output, progress, allowed_entries,
        )
        collection_archive = None
        if archive_path is not None:
            collection_archive = _archive_collected_artifacts(
                Path(prepared_input), archive_path, progress,
            )
            published['collected_artifacts'] = str(archive_path)

    return {
        'profile': profile.metadata,
        'prepared_input': prepared_input,
        'raw_records': len(raw_records),
        'observations': len(observations),
        'inferences': len(inferences),
        'problems': len(problems),
        'status': 'completed_with_problems' if problems else 'completed',
        'acquisition': acquisition.as_dict() if acquisition is not None else None,
        'collected_artifacts': collection_archive,
        'team_share': published,
        'output': str(output),
    }

from __future__ import annotations

import ctypes
import fnmatch
import json
import os
import platform
import re
import shutil
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .acquisition import collection_definition, normalize_rel


class VssError(RuntimeError):
    """Raised when a live-system VSS acquisition cannot be completed."""


@dataclass(frozen=True)
class VssSnapshot:
    snapshot_id: str
    device: str
    volume: str


def is_windows_admin() -> bool:
    if platform.system().lower() != 'windows':
        return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except (AttributeError, OSError):
        return False


def system_volume(path: str | Path | None = None) -> str:
    value = Path(path or os.environ.get('USERPROFILE') or Path.cwd()).resolve()
    drive = value.drive
    if not re.fullmatch(r'[A-Za-z]:', drive):
        raise VssError(f'VSS 대상 Windows 볼륨을 확인할 수 없습니다: {value}')
    return drive.upper() + '\\'


def _powershell(script: str) -> str:
    completed = subprocess.run(
        [
            'powershell.exe', '-NoProfile', '-NonInteractive',
            '-ExecutionPolicy', 'Bypass', '-Command', script,
        ],
        check=False,
        capture_output=True,
        text=True,
        encoding='utf-8',
        errors='replace',
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
    )
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout or '').strip()
        raise VssError(f'VSS PowerShell 명령이 실패했습니다: {detail or completed.returncode}')
    return completed.stdout.strip()


def create_snapshot(volume: str) -> VssSnapshot:
    if platform.system().lower() != 'windows':
        raise VssError('VSS 라이브 수집은 Windows에서만 지원합니다.')
    if not is_windows_admin():
        raise VssError(
            'VSS 스냅샷 생성에는 관리자 권한이 필요합니다. '
            'PowerShell을 관리자 권한으로 실행한 뒤 다시 시도하세요.'
        )
    if not re.fullmatch(r'[A-Za-z]:\\', volume):
        raise VssError(f'잘못된 VSS 볼륨 경로입니다: {volume}')
    safe_volume = volume.replace("'", "''")
    script = rf'''
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new()
$ErrorActionPreference = 'Stop'
$result = Invoke-CimMethod -ClassName Win32_ShadowCopy -MethodName Create -Arguments @{{Volume='{safe_volume}'; Context='ClientAccessible'}}
if ([int]$result.ReturnValue -ne 0) {{ throw "Win32_ShadowCopy.Create ReturnValue=$($result.ReturnValue)" }}
$shadow = Get-CimInstance -ClassName Win32_ShadowCopy | Where-Object {{ $_.ID -eq $result.ShadowID }} | Select-Object -First 1
if ($null -eq $shadow) {{ throw '생성된 VSS 스냅샷을 다시 찾지 못했습니다.' }}
[pscustomobject]@{{id=$shadow.ID; device=$shadow.DeviceObject}} | ConvertTo-Json -Compress
'''
    output = _powershell(script)
    try:
        payload = json.loads(output.splitlines()[-1])
    except (IndexError, json.JSONDecodeError) as exc:
        raise VssError(f'VSS 생성 결과를 해석할 수 없습니다: {output}') from exc
    snapshot_id = str(payload.get('id') or '')
    device = str(payload.get('device') or '').rstrip('\\/')
    if not re.fullmatch(r'\{[0-9A-Fa-f-]+\}', snapshot_id):
        raise VssError(f'VSS snapshot ID가 올바르지 않습니다: {snapshot_id}')
    if not device.lower().startswith(r'\\?\globalroot\device\harddiskvolumeshadowcopy'):
        raise VssError(f'VSS device 경로가 올바르지 않습니다: {device}')
    return VssSnapshot(snapshot_id=snapshot_id, device=device, volume=volume)


def delete_snapshot(snapshot: VssSnapshot) -> None:
    snapshot_id = snapshot.snapshot_id
    if not re.fullmatch(r'\{[0-9A-Fa-f-]+\}', snapshot_id):
        raise VssError(f'삭제할 VSS snapshot ID가 올바르지 않습니다: {snapshot_id}')
    safe_id = snapshot_id.replace("'", "''")
    script = rf'''
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new()
$ErrorActionPreference = 'Stop'
$shadow = Get-CimInstance -ClassName Win32_ShadowCopy | Where-Object {{ $_.ID -eq '{safe_id}' }} | Select-Object -First 1
if ($null -ne $shadow) {{ Remove-CimInstance -InputObject $shadow }}
'''
    _powershell(script)


def _matches_any(relative_path: str, patterns: list[str]) -> bool:
    lowered = normalize_rel(relative_path).lower()
    return any(
        fnmatch.fnmatchcase(lowered, normalize_rel(pattern).lower())
        for pattern in patterns
    )


def _with_sqlite_sidecars(patterns: list[str]) -> tuple[list[str], list[str]]:
    """Add SQLite WAL/journal files needed to read an open-browser snapshot."""
    database_names = {'history', 'cookies', 'dips', 'favicons'}
    effective = list(patterns)
    added: list[str] = []
    for pattern in patterns:
        name = normalize_rel(pattern).rsplit('\\', 1)[-1].lower()
        if name not in database_names:
            continue
        for suffix in ('-journal', '-wal', '-shm'):
            sidecar = str(pattern) + suffix
            if sidecar not in effective:
                effective.append(sidecar)
                added.append(sidecar)
    return effective, added


def _iter_literal_root_glob(root: str, pattern: str):
    r"""Expand a volume-relative glob without globbing the VSS device prefix.

    ``glob`` treats the question mark in ``\\?\GLOBALROOT`` as a wildcard and
    consequently returns no files for real shadow-copy device paths.  This
    walker keeps the root literal and applies wildcard matching only to the
    profile-controlled relative path components.
    """
    parts = [part for part in normalize_rel(pattern).split('\\') if part]

    def walk(base: str, index: int):
        if index >= len(parts):
            if os.path.isfile(base):
                yield base
            return

        part = parts[index]
        last = index == len(parts) - 1
        if part == '**':
            if last:
                for directory, _, filenames in os.walk(base):
                    for filename in filenames:
                        yield os.path.join(directory, filename)
                return
            yield from walk(base, index + 1)
            try:
                with os.scandir(base) as entries:
                    directories = [
                        entry.path for entry in entries
                        if entry.is_dir(follow_symlinks=False)
                    ]
            except OSError:
                return
            for directory in directories:
                yield from walk(directory, index)
            return

        has_magic = any(char in part for char in '*?[')
        if not has_magic:
            candidate = os.path.join(base, part)
            if last:
                if os.path.isfile(candidate):
                    yield candidate
            elif os.path.isdir(candidate):
                yield from walk(candidate, index + 1)
            return

        try:
            with os.scandir(base) as entries:
                matches = [
                    entry for entry in entries
                    if fnmatch.fnmatchcase(entry.name.lower(), part.lower())
                ]
        except OSError:
            return
        for entry in matches:
            try:
                if last and entry.is_file(follow_symlinks=False):
                    yield entry.path
                elif not last and entry.is_dir(follow_symlinks=False):
                    yield from walk(entry.path, index + 1)
            except OSError:
                continue

    yield from walk(str(root).rstrip('\\/'), 0)


def collect_snapshot_artifacts(snapshot: VssSnapshot, destination: str | Path,
                               profile: Any, *, include_noise: bool = False) \
        -> dict[str, Any]:
    """Copy only profile-selected artifacts from a snapshot into a case folder."""
    target_root = Path(destination).resolve()
    if target_root.exists() and any(target_root.iterdir()):
        raise VssError(
            f'VSS 아티팩트 저장 폴더가 비어 있지 않습니다: {target_root}. '
            '새 결과 폴더를 지정하세요.'
        )
    target_root.mkdir(parents=True, exist_ok=True)

    image = dict((collection_definition(profile).get('image') or {}))
    declared_include_patterns = list(image.get('include') or ())
    include_patterns, implicit_sidecars = _with_sqlite_sidecars(
        declared_include_patterns
    )
    exclude_patterns = list(image.get('exclude') or ())
    noise_patterns = list(image.get('noise') or ())
    max_file = int(image.get('max_file_bytes') or 512 * 1024 * 1024)
    if image.get('syntax', 'glob') != 'glob' or not include_patterns:
        raise VssError(
            f'{profile.name} 프로필에 VSS 수집용 glob include 정의가 없습니다.'
        )

    volume_letter = snapshot.volume[:1].upper()
    copied: list[dict[str, Any]] = []
    problems: list[dict[str, str]] = []
    seen: set[str] = set()
    for pattern in include_patterns:
        for source_text in _iter_literal_root_glob(
            snapshot.device, str(pattern),
        ):
            source_key = os.path.normcase(os.path.normpath(source_text))
            if source_key in seen:
                continue
            seen.add(source_key)
            try:
                if not os.path.isfile(source_text):
                    continue
                relative = os.path.relpath(source_text, snapshot.device)
                normalized = normalize_rel(relative)
                if normalized.startswith('..'):
                    raise VssError(f'VSS 범위를 벗어난 경로입니다: {source_text}')
                if _matches_any(normalized, exclude_patterns):
                    continue
                if not include_noise and _matches_any(normalized, noise_patterns):
                    continue
                size = os.path.getsize(source_text)
                if size > max_file:
                    problems.append({
                        'path': normalized,
                        'error': f'max_file_bytes 초과: {size} > {max_file}',
                    })
                    continue
                saved = target_root / volume_letter / Path(relative)
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source_text, saved)
                copied.append({
                    'source_path': f'{volume_letter}:\\{normalized}',
                    'saved_path': str(saved.relative_to(target_root)),
                    'size': size,
                })
            except (OSError, VssError) as exc:
                problems.append({
                    'path': str(source_text),
                    'error': f'{type(exc).__name__}: {exc}',
                })

    manifest = {
        'format': 'LLMTrace VSS acquisition',
        'version': 1,
        'created_at': datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
        'profile': profile.name,
        'snapshot_id': snapshot.snapshot_id,
        'snapshot_device': snapshot.device,
        'source_volume': snapshot.volume,
        'files_found': len(copied) + len(problems),
        'files_written': len(copied),
        'problem_count': len(problems),
        'include': declared_include_patterns,
        'implicit_sqlite_sidecars': implicit_sidecars,
        'exclude': exclude_patterns,
        'noise_excluded': [] if include_noise else noise_patterns,
        'files': copied,
        'problems': problems,
        'output': str(target_root),
    }
    manifest_path = target_root / 'vss_collection.json'
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding='utf-8',
    )
    if not copied:
        raise VssError(
            'VSS 스냅샷은 생성했지만 프로필 수집 대상 파일을 찾지 못했습니다. '
            f'진단 정보: {manifest_path}'
        )
    return manifest
